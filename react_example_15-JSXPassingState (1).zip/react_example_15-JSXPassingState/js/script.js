const root = ReactDOM.createRoot(document.getElementById('content'));
root.render(<Clock />);