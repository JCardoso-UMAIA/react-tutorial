const DigitalDisplay = (props) => {
  return <div>{props.time}</div>;
};