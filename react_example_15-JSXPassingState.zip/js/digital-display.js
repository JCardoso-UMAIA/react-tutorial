import React from 'react';

const DigitalDisplay = ({ time }) => (
  <div>{time}</div>
);

export default DigitalDisplay;