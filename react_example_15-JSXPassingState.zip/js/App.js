import React from 'react';
import Clock from './Clock';

const App = () => (
  <div>
    <h1>JSX Passing State Example</h1>
    <Clock />
  </div>
);

export default App;